"""Offline tests for topology checks and descriptive summaries."""

import unittest

import evidence


class EvidenceGuards(unittest.TestCase):
    def test_connected_tree(self) -> None:
        self.assertTrue(
            evidence.graph_connected([{"spanId": "1"}, {"spanId": "2", "parentSpanId": "1"}])
        )

    def test_missing_parent_and_cycles_are_not_connected(self) -> None:
        self.assertFalse(
            evidence.graph_connected([{"spanId": "1"}, {"spanId": "2", "parentSpanId": "3"}])
        )
        self.assertFalse(
            evidence.graph_connected(
                [
                    {"spanId": "1"},
                    {"spanId": "2", "parentSpanId": "3"},
                    {"spanId": "3", "parentSpanId": "2"},
                ]
            )
        )

    def test_duplicate_span_ids_fail(self) -> None:
        self.assertFalse(evidence.graph_connected([{"spanId": "1"}, {"spanId": "1"}]))

    def test_unknown_span_names_are_not_exported(self) -> None:
        self.assertEqual(evidence.safe_span_name("unapproved label"), "[other span]")
        self.assertEqual(
            evidence.safe_span_name("invoke_agent policy_gate"), "invoke_agent policy_gate"
        )

    def test_empty_and_nonempty_descriptions(self) -> None:
        self.assertEqual(
            evidence.describe([]),
            {"n": 0, "minimum": None, "median": None, "maximum": None},
        )
        self.assertEqual(
            evidence.describe([3.0, 1.0, 2.0]),
            {"n": 3, "minimum": 1.0, "median": 2.0, "maximum": 3.0},
        )


if __name__ == "__main__":
    unittest.main()
