"""Read-only trace capture and offline integrity checks for the live validation."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
import sys
import zipfile
from datetime import timedelta
from pathlib import Path
from typing import Any
from uuid import UUID

import collect
import google.auth
from google.auth.credentials import CredentialsWithQuotaProject
from google.auth.transport.requests import AuthorizedSession

from model_armor.redaction import contains_sensitive

HERE = Path(__file__).resolve().parent
TRACE_FILE = HERE / "pilot-trace.json"
PUBLIC_SPANS = {
    "invoke_workflow orchestrator",
    "invoke_agent orchestrator",
    *(f"invoke_agent {actor}" for actor in collect.STEPS),
    "a2a.client.transports.jsonrpc.JsonRpcTransport.send_message",
    "/google.firestore.v1.Firestore/BatchGetDocuments",
    "GET",
    "POST",
}


def graph_connected(spans: list[dict[str, Any]]) -> bool:
    identifiers = {span["spanId"] for span in spans}
    if len(identifiers) != len(spans):
        return False
    roots = [span["spanId"] for span in spans if span.get("parentSpanId", "0") in {"0", ""}]
    if len(roots) != 1:
        return False
    children: dict[str, list[str]] = {}
    for span in spans:
        parent = span.get("parentSpanId", "0")
        if parent in {"0", ""}:
            continue
        if parent not in identifiers:
            return False
        children.setdefault(parent, []).append(span["spanId"])
    visited = set()
    remaining = list(roots)
    while remaining:
        identifier = remaining.pop()
        if identifier in visited:
            return False
        visited.add(identifier)
        remaining.extend(children.get(identifier, []))
    return visited == identifiers


def safe_span_name(value: str) -> str:
    return value if value in PUBLIC_SPANS else "[other span]"


def trace_pilot(state: dict[str, Any]) -> None:
    row = state["runs"][0]
    if row["validation"] != "passed":
        raise collect.MeasurementStop("pilot_must_pass_before_trace_capture")
    bounds = [
        event
        for event in row["audit_events"]
        if event["actor"] == "orchestrator" and event["event"] == "investigation.run"
    ]
    audit_start = min(
        collect.timestamp(event["timestamp"]) for event in bounds if event["outcome"] == "started"
    )
    audit_end = max(
        collect.timestamp(event["timestamp"]) for event in bounds if event["outcome"] == "completed"
    )
    credentials, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
    if not isinstance(credentials, CredentialsWithQuotaProject):
        raise collect.MeasurementStop("quota_project_selection_unavailable")
    candidates = []
    with AuthorizedSession(credentials.with_quota_project(collect.PROJECT)) as session:
        token = None
        for _page in range(4):
            params = {
                "startTime": (
                    collect.timestamp(row["published_at"]) - timedelta(seconds=10)
                ).isoformat(),
                "endTime": (audit_end + timedelta(seconds=10)).isoformat(),
                "view": "COMPLETE",
                "pageSize": 1000,
                "fields": (
                    "traces(traceId,spans(spanId,parentSpanId,name,startTime,endTime)),"
                    "nextPageToken"
                ),
            }
            if token:
                params["pageToken"] = token
            response = session.get(
                f"https://cloudtrace.googleapis.com/v1/projects/{collect.PROJECT}/traces",
                params=params,
                timeout=60,
            )
            if response.status_code != 200:
                raise collect.MeasurementStop(f"trace_read_http_{response.status_code}")
            data = response.json()
            for trace in data.get("traces", []):
                for span in trace.get("spans", []):
                    if span.get("name") != "invoke_workflow orchestrator":
                        continue
                    start_delta = (
                        collect.timestamp(span["startTime"]) - audit_start
                    ).total_seconds()
                    end_delta = (collect.timestamp(span["endTime"]) - audit_end).total_seconds()
                    if abs(start_delta) <= 1 and abs(end_delta) <= 1:
                        candidates.append((trace, start_delta, end_delta))
            token = data.get("nextPageToken")
            if not token:
                break
        if token:
            raise collect.MeasurementStop("trace_page_limit_exceeded")
    if len(candidates) != 1:
        raise collect.MeasurementStop("unique_time_matched_pilot_trace_not_found")
    trace, start_delta, end_delta = candidates[0]
    spans = trace["spans"]
    orchestrators = [span for span in spans if span["name"] == "invoke_agent orchestrator"]
    if len(orchestrators) != 1:
        raise collect.MeasurementStop("trace_orchestrator_span_ambiguous")
    parent = orchestrators[0]["spanId"]
    stages = []
    for actor in collect.STEPS:
        matches = [
            span
            for span in spans
            if span["name"] == f"invoke_agent {actor}" and span.get("parentSpanId") == parent
        ]
        if len(matches) != 1:
            raise collect.MeasurementStop("required_trace_step_missing_or_ambiguous")
        stage = matches[0]
        stages.append(
            {
                "step": actor,
                "start_time": stage["startTime"],
                "end_time": stage["endTime"],
                "duration_seconds": (
                    collect.timestamp(stage["endTime"]) - collect.timestamp(stage["startTime"])
                ).total_seconds(),
            }
        )
    starts = [collect.timestamp(stage["start_time"]) for stage in stages]
    ordered = starts == sorted(starts)
    connected = graph_connected(spans)
    output = {
        "observed_at": collect.utc_now(),
        "original_run": 1,
        "trace_id": trace["traceId"],
        "correlation_method": (
            "Unique invoke_workflow orchestrator span whose start and end are each "
            "within one second of the pilot Runtime audit boundaries."
        ),
        "embedded_investigation_id_join": False,
        "start_delta_seconds_from_audit": start_delta,
        "end_delta_seconds_from_audit": end_delta,
        "span_count": len(spans),
        "connected_single_tree": connected,
        "five_steps_in_order": ordered,
        "steps": stages,
        "span_attributes_requested": False,
        "unrecognized_span_names_coarsened": sum(
            span["name"] not in PUBLIC_SPANS for span in spans
        ),
        "spans": [
            {
                "span_id": span["spanId"],
                "parent_span_id": span.get("parentSpanId", "0"),
                "name": safe_span_name(span["name"]),
                "start_time": span["startTime"],
                "end_time": span["endTime"],
            }
            for span in spans
        ],
    }
    if contains_sensitive(json.dumps(output)):
        raise collect.MeasurementStop("trace_metadata_failed_protected_shape_check")
    TRACE_FILE.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    if not connected or not ordered:
        raise collect.MeasurementStop("trace_topology_or_order_check_failed")
    print(
        json.dumps(
            {
                "pilot_trace_captured": True,
                "span_count": len(spans),
                "connected_single_tree": connected,
                "five_steps_in_order": ordered,
                "correlation_method": "unique_root_name_and_audit_timestamp_window",
                "span_attributes_requested": False,
            },
            indent=2,
        )
    )


def describe(values: list[float]) -> dict[str, float | int | None]:
    return {
        "n": len(values),
        "minimum": min(values) if values else None,
        "median": statistics.median(values) if values else None,
        "maximum": max(values) if values else None,
    }


def finalize(state: dict[str, Any]) -> None:
    if state["phase"] not in {"completed", "stopped", "collector_error", "pilot_passed"}:
        raise collect.MeasurementStop("collector_has_not_finished")
    runs = state["runs"]
    if len(runs) > collect.MAX_NEW or len(state["replays"]) > collect.MAX_REPLAYS:
        raise collect.MeasurementStop("authorized_publication_count_exceeded")
    ids = [row["event"]["event_id"] for row in runs]
    if len(ids) != len(set(ids)):
        raise collect.MeasurementStop("duplicate_unique_event_identity")
    contexts = [row["event"]["context_id"] for row in runs]
    if len(contexts) != len(set(contexts)):
        raise collect.MeasurementStop("duplicate_investigation_context")
    for row in runs:
        if set(row["event"]) != {
            "event_id",
            "context_id",
            "schema_version",
            "classification",
            "mock_data",
        }:
            raise collect.MeasurementStop("unexpected_event_envelope_fields")
        UUID(row["event"]["event_id"])
        UUID(row["event"]["context_id"])
        if row["event"]["mock_data"] is not False:
            raise collect.MeasurementStop("unexpected_synthetic_input")
    for row in [*runs, *state["replays"]]:
        elapsed = (
            collect.timestamp(row["published_at"])
            - collect.timestamp(state["first_publication_at"])
        ).total_seconds()
        if not 0 <= elapsed < collect.WINDOW_SECONDS:
            raise collect.MeasurementStop("publication_outside_original_window")
    source_hash = hashlib.sha256((HERE / "collect.py").read_bytes()).hexdigest()
    if source_hash != state["collector_sha256"]:
        raise collect.MeasurementStop("collector_source_changed")
    preflight = json.loads((HERE / "preflight.json").read_text(encoding="utf-8"))
    if contains_sensitive(json.dumps(state)) or contains_sensitive(json.dumps(preflight)):
        raise collect.MeasurementStop("measurement_failed_protected_shape_check")
    passed = [row for row in runs if row["validation"] == "passed"]
    for row in passed:
        if collect.audit_gaps(row["audit_events"]):
            raise collect.MeasurementStop("validated_run_has_audit_gaps")
        if row["durable"]["status"] != "completed" or row["durable"]["attempts"] != 1:
            raise collect.MeasurementStop("validated_run_has_invalid_durable_state")
    stage_statistics = {
        actor: describe([row["audit_durations_seconds"][actor] for row in passed])
        for actor in ("orchestrator", *collect.STEPS)
    }
    models: dict[str, int] = {}
    for row in runs:
        for event in row["audit_events"]:
            if event["event"] == "model.request" and event["outcome"] == "submitted":
                model = event.get("model", "not_recorded")
                models[model] = models.get(model, 0) + 1
    summary = {
        "observed_date_utc": state["created_at"][:10],
        "final_phase": state["phase"],
        "stop_reason": state.get("stop_reason"),
        "project_count": 1,
        "input": "Existing real-IAM product path; no retained raw policy snapshots.",
        "sample_boundary": (
            "Repeated executions on one project, not independent IAM policies, detector "
            "accuracy, explanation usefulness, a leakage rate, or historical SLO attainment."
        ),
        "counts": collect.summarize(state),
        "validated_run_audit_events": sum(len(row["audit_events"]) for row in passed),
        "all_attempt_audit_events_captured": sum(len(row["audit_events"]) for row in runs),
        "validated_run_invocations": sum(
            len({event["invocation_id"] for event in row["audit_events"]}) for row in passed
        ),
        "validated_run_review_records": sum(len(row["reviews"]) for row in passed),
        "validated_run_delivered_findings": sum(
            record["finding_count"] for row in passed for record in row["reviews"]
        ),
        "model_submissions_captured": models,
        "confirmation_latency_method": state["method"]["confirmation_latency"],
        "poll_interval_seconds": collect.POLL_SECONDS,
        "audit_duration_seconds": stage_statistics,
        "replay_boundary": state["method"]["replay_boundary"],
        "replays_with_unchanged_effects_observed": sum(
            replay.get("observation") == "unchanged_effects_during_bounded_window"
            for replay in state["replays"]
        ),
        "authorization_ceiling_sek": state["authorization"]["ceiling_sek"],
        "actual_cost_sek": None,
        "actual_cost_status": "Not available from the payload-free audit; billing is delayed.",
        "deployment_provenance": preflight,
        "collector_sha256": source_hash,
        "collector_history": state.get("collector_history", []),
        "collector_repair": state.get("collector_repair"),
        "original_stops_preserved": state.get("previous_stops", []),
        "runs_with_readonly_evidence_recovery": sum("evidence_recovery" in row for row in runs),
        "analysis_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "protected_shape_check_passed": True,
    }
    if TRACE_FILE.exists():
        trace = json.loads(TRACE_FILE.read_text(encoding="utf-8"))
        if contains_sensitive(json.dumps(trace)):
            raise collect.MeasurementStop("trace_metadata_failed_protected_shape_check")
        summary["pilot_trace"] = {
            key: trace[key]
            for key in (
                "span_count",
                "connected_single_tree",
                "five_steps_in_order",
                "correlation_method",
                "embedded_investigation_id_join",
                "span_attributes_requested",
            )
        }
    files = [
        "collect.py",
        "test_collect.py",
        "evidence.py",
        "test_evidence.py",
        "preflight.json",
        "metrics.json",
        "runs.csv",
        "stages.csv",
        "summary.json",
    ]
    if TRACE_FILE.exists():
        files.append(TRACE_FILE.name)
    if state.get("collector_history"):
        initial_path = HERE / "initial-stop-collector-v1.zip"
        with zipfile.ZipFile(initial_path) as initial:
            original_source = initial.read("collect.py")
            original_checkpoint = initial.read("metrics.json")
            original_state = json.loads(original_checkpoint)
        if (
            hashlib.sha256(initial_path.read_bytes()).hexdigest()
            != state["collector_history"][0]["source_archive_sha256"]
        ):
            raise collect.MeasurementStop("original_archive_history_hash_mismatch")
        if (
            hashlib.sha256(original_checkpoint).hexdigest()
            != state["previous_stops"][0]["checkpoint_sha256"]
        ):
            raise collect.MeasurementStop("original_checkpoint_history_hash_mismatch")
        if hashlib.sha256(original_source).hexdigest() != state["collector_history"][0]["sha256"]:
            raise collect.MeasurementStop("original_source_history_hash_mismatch")
        original_runs = original_state["runs"]
        for before, after in zip(original_runs, runs[: len(original_runs)], strict=True):
            for key in (
                "event",
                "published_at",
                "publish_status",
                "publish_ack_seconds",
                "confirmation_seconds",
                "observations",
                "durable",
                "reviews",
            ):
                if before.get(key) != after.get(key):
                    raise collect.MeasurementStop("original_execution_facts_changed")
        if original_state["first_publication_at"] != state["first_publication_at"]:
            raise collect.MeasurementStop("original_collection_window_changed")
        files.extend(["initial-stop-collector-v1.zip", "run-07-readonly-recovery.json"])
        if (HERE / "run-07-log-visibility.json").exists():
            files.append("run-07-log-visibility.json")
    for optional in ("runtime-source-provenance.json", "deployment-verification.json"):
        path = HERE / optional
        if path.exists():
            contents = json.loads(path.read_text(encoding="utf-8"))
            if contains_sensitive(json.dumps(contents)):
                raise collect.MeasurementStop("supplement_failed_protected_shape_check")
            summary[optional.removesuffix(".json").replace("-", "_")] = contents
            files.append(optional)
    (HERE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with (HERE / "stages.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["run", "stage", "audit_duration_seconds"])
        writer.writeheader()
        for row in passed:
            for stage, seconds in row["audit_durations_seconds"].items():
                writer.writerow(
                    {"run": row["number"], "stage": stage, "audit_duration_seconds": seconds}
                )
    hashes = {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in files}
    (HERE / "sha256.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(
        HERE / "bastion-live-validation-2026-10-27.zip", "w", zipfile.ZIP_DEFLATED
    ) as archive:
        for name in [*files, "sha256.json"]:
            archive.write(HERE / name, arcname=name)
    print(json.dumps(summary, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--trace-pilot", action="store_true")
    mode.add_argument("--finalize", action="store_true")
    args = parser.parse_args()
    state = json.loads(collect.STATE_FILE.read_text(encoding="utf-8"))
    if args.trace_pilot:
        trace_pilot(state)
    else:
        finalize(state)


if __name__ == "__main__":
    sys.excepthook = collect.safe_exception_hook
    try:
        main()
    except collect.MeasurementStop as error:
        print(json.dumps({"evidence_stop_reason": str(error)}), file=sys.stderr)
        raise SystemExit(2) from None
