"""Count-bounded, payload-free observations of the existing Bastion fleet."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import statistics
import sys
import time
import zipfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import google.auth
from google.api_core.exceptions import GoogleAPIError
from google.api_core.retry import Retry
from google.auth.credentials import CredentialsWithQuotaProject
from google.auth.exceptions import GoogleAuthError
from google.auth.transport.requests import AuthorizedSession
from google.cloud import firestore, pubsub_v1
from google.cloud.firestore_v1.base_query import FieldFilter
from requests.exceptions import RequestException

from registry.departments import load_catalog
from runtime.events import new_investigation_payload

PROJECT = "bastion-fleet-2026"
HERE = Path(__file__).resolve().parent
STATE_FILE = HERE / "metrics.json"
LOCK_FILE = HERE / "collector.lock"
MAX_NEW = 20
MAX_REPLAYS = 5
WINDOW_SECONDS = 3600
RUN_SECONDS = 600
AUDIT_SECONDS = 120
REPLAY_SECONDS = 120
POLL_SECONDS = 5
RETRY = Retry(initial=1, maximum=3, deadline=20)
ACTORS = {
    "orchestrator",
    "access_auditor",
    "policy_step",
    "policy_gate",
    "escalation_agent",
    "escalation_gate",
    "audit_iam_policy",
    "notify_human",
    "durable_ingress",
    "model-armor",
    "protected-data-filter",
}
EVENTS = {
    "investigation.run",
    "agent.run",
    "model.request",
    "tool.call",
    "model_armor.input",
    "model_armor.output",
    "auditor.fidelity",
    "escalation.envelope",
    "runtime.dispatch",
}
OUTCOMES = {"started", "submitted", "completed", "failed", "refused", "rejected"}
STEPS = ("access_auditor", "policy_step", "policy_gate", "escalation_agent", "escalation_gate")


class MeasurementStop(RuntimeError):
    """A bounded reason to stop publishing, never a provider error message."""


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def timestamp(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def persist(state: dict[str, Any]) -> None:
    state["last_checkpoint_at"] = utc_now()
    temporary = STATE_FILE.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    temporary.replace(STATE_FILE)


def check_publication_limit(state: dict[str, Any], kind: str) -> None:
    limit = MAX_NEW if kind == "new" else MAX_REPLAYS
    records = state["runs"] if kind == "new" else state["replays"]
    if len(records) >= limit:
        raise MeasurementStop("publication_count_limit")
    started = state.get("first_publication_at")
    if started and (datetime.now(UTC) - timestamp(started)).total_seconds() >= WINDOW_SECONDS:
        raise MeasurementStop("collection_window_expired")


def check_window(state: dict[str, Any]) -> None:
    started = state.get("first_publication_at")
    if started and (datetime.now(UTC) - timestamp(started)).total_seconds() >= WINDOW_SECONDS:
        raise MeasurementStop("collection_window_expired")


def safe_audit(entry: dict[str, Any], event_id: str) -> dict[str, Any]:
    data = entry.get("jsonPayload", {})
    if data.get("investigation_id") != event_id:
        raise MeasurementStop("audit_correlation_mismatch")
    if (
        data.get("actor") not in ACTORS
        or data.get("event") not in EVENTS
        or data.get("outcome") not in OUTCOMES
    ):
        raise MeasurementStop("unexpected_audit_metadata")
    invocation = data.get("invocation_id")
    if (
        not isinstance(invocation, str)
        or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", invocation)
        or invocation == "unknown"
    ):
        raise MeasurementStop("invalid_invocation_metadata")
    observed_at = entry.get("timestamp")
    if not isinstance(observed_at, str):
        raise MeasurementStop("missing_audit_timestamp")
    timestamp(observed_at)
    record = {
        "timestamp": observed_at,
        "insert_id": entry["insertId"],
        "event": data["event"],
        "outcome": data["outcome"],
        "actor": data["actor"],
        "invocation_id": invocation,
    }
    detail = data.get("detail", {})
    model = detail.get("model")
    if model is not None:
        if not isinstance(model, str) or not re.fullmatch(r"gemini-[a-zA-Z0-9.-]{1,80}", model):
            raise MeasurementStop("unexpected_model_identifier")
        record["model"] = model
    error = detail.get("error", detail.get("error_type"))
    if error is not None:
        if not isinstance(error, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,80}", error):
            raise MeasurementStop("unexpected_error_metadata")
        record["error_class"] = error
    trace = entry.get("trace", "").rsplit("/", 1)[-1]
    if trace:
        if not re.fullmatch(r"[0-9a-f]{32}", trace):
            raise MeasurementStop("unexpected_trace_identifier")
        record["trace_id"] = trace
    return record


def audit_gaps(events: list[dict[str, Any]]) -> list[str]:
    if any(event["outcome"] in {"failed", "refused", "rejected"} for event in events):
        raise MeasurementStop("audit_failure_or_refusal")
    root_ids = {
        event["invocation_id"]
        for event in events
        if event["actor"] == "orchestrator" and event["event"] == "investigation.run"
    }
    gaps = []
    if len(root_ids) != 1:
        gaps.append("one_runtime_invocation")
    for actor in ("orchestrator", "access_auditor", "escalation_agent"):
        for outcome in ("started", "completed"):
            if not any(
                event["actor"] == actor
                and event["event"] == "investigation.run"
                and event["outcome"] == outcome
                for event in events
            ):
                gaps.append(f"{actor}_{outcome}")
    for actor in STEPS:
        for outcome, boundary in (("started", "start"), ("completed", "completion")):
            if not any(
                event["actor"] == actor
                and event["event"] == "agent.run"
                and event["outcome"] == outcome
                and event["invocation_id"] in root_ids
                for event in events
            ):
                gaps.append(f"{actor}_runtime_{boundary}")
    if not any(
        event["actor"] == "audit_iam_policy"
        and event["event"] == "tool.call"
        and event["outcome"] == "completed"
        for event in events
    ):
        gaps.append("iam_tool_completion")
    submitted = sum(
        event["event"] == "model.request" and event["outcome"] == "submitted" for event in events
    )
    completed = sum(
        event["event"] == "model.request" and event["outcome"] == "completed" for event in events
    )
    if submitted == 0 or submitted != completed:
        gaps.append("paired_model_calls")
    if submitted > 4:
        raise MeasurementStop("unexpected_model_call_count")
    if len({event["invocation_id"] for event in events}) != 3:
        gaps.append("three_correlated_invocations")
    return gaps


def durations(events: list[dict[str, Any]]) -> dict[str, float]:
    roots = {
        event["invocation_id"]
        for event in events
        if event["actor"] == "orchestrator" and event["event"] == "investigation.run"
    }
    result = {}
    for actor in ("orchestrator", *STEPS):
        event_type = "investigation.run" if actor == "orchestrator" else "agent.run"
        selected = [
            event
            for event in events
            if event["actor"] == actor
            and event["event"] == event_type
            and event["invocation_id"] in roots
        ]
        starts = [
            timestamp(event["timestamp"]) for event in selected if event["outcome"] == "started"
        ]
        ends = [
            timestamp(event["timestamp"]) for event in selected if event["outcome"] == "completed"
        ]
        if not starts or not ends:
            raise MeasurementStop("missing_audit_duration_boundary")
        seconds = (max(ends) - min(starts)).total_seconds()
        if not math.isfinite(seconds) or seconds < 0:
            raise MeasurementStop("invalid_audit_duration")
        result[actor] = round(seconds, 6)
    return result


class Observer:
    def __init__(self) -> None:
        credentials, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        if not isinstance(credentials, CredentialsWithQuotaProject):
            raise MeasurementStop("quota_project_selection_unavailable")
        credentials = credentials.with_quota_project(PROJECT)
        self.client = firestore.Client(project=PROJECT, credentials=credentials)
        self.publisher = pubsub_v1.PublisherClient(credentials=credentials)
        self.session = AuthorizedSession(credentials)
        self.departments = {entry["id"] for entry in load_catalog()}

    def close(self) -> None:
        self.publisher.stop()
        self.client.close()
        self.session.close()

    def durable(self, event_id: str) -> dict[str, Any]:
        snapshot = (
            self.client.collection("bastion_investigations")
            .document(event_id)
            .get(field_paths=["status", "attempts", "updated_at"], retry=RETRY, timeout=30)
        )
        if not snapshot.exists:
            return {"status": "not_received", "attempts": 0}
        data = snapshot.to_dict()
        status = data.get("status")
        attempts = data.get("attempts")
        if status not in {"received", "running", "completed", "failed"}:
            raise MeasurementStop("invalid_durable_status")
        if type(attempts) is not int or attempts < 0:
            raise MeasurementStop("invalid_attempt_count")
        updated = data.get("updated_at")
        if not isinstance(updated, datetime):
            raise MeasurementStop("missing_durable_timestamp")
        return {"status": status, "attempts": attempts, "updated_at": updated.isoformat()}

    def reviews(self, event_id: str) -> list[dict[str, Any]]:
        query = (
            self.client.collection("bastion_human_review")
            .where(filter=FieldFilter("investigation_id", "==", event_id))
            .select(["department", "finding_count"])
        )
        records = []
        seen = set()
        for snapshot in query.stream(retry=RETRY, timeout=30):
            data = snapshot.to_dict()
            department = data.get("department")
            count = data.get("finding_count")
            if department not in self.departments or department in seen:
                raise MeasurementStop("unknown_or_duplicate_review_department")
            if type(count) is not int or count <= 0:
                raise MeasurementStop("invalid_review_count")
            expected_key = hashlib.sha256(f"{event_id}:{department}".encode()).hexdigest()
            if snapshot.id != expected_key:
                raise MeasurementStop("review_idempotency_key_mismatch")
            seen.add(department)
            records.append({"department": department, "finding_count": count})
        return sorted(records, key=lambda record: record["department"])

    def audit(self, event_id: str, since: str) -> list[dict[str, Any]]:
        records = {}
        token = None
        for _page in range(4):
            body = {
                "resourceNames": [f"projects/{PROJECT}"],
                "filter": (f'jsonPayload.investigation_id="{event_id}" AND timestamp>="{since}"'),
                "orderBy": "timestamp asc",
                "pageSize": 500,
            }
            if token:
                body["pageToken"] = token
            response = self.session.post(
                "https://logging.googleapis.com/v2/entries:list",
                params={"fields": "entries(insertId,timestamp,jsonPayload,trace),nextPageToken"},
                json=body,
                timeout=60,
            )
            if response.status_code != 200:
                raise MeasurementStop(f"logging_read_http_{response.status_code}")
            data = response.json()
            for entry in data.get("entries", []):
                record = safe_audit(entry, event_id)
                records[(record["insert_id"], record["timestamp"])] = record
            token = data.get("nextPageToken")
            if not token:
                return sorted(records.values(), key=lambda record: record["timestamp"])
        raise MeasurementStop("audit_page_limit_exceeded")

    def publish(self, event: dict[str, Any]) -> None:
        future = self.publisher.publish(
            self.publisher.topic_path(PROJECT, "bastion-investigations"),
            json.dumps(event, sort_keys=True).encode(),
            retry=RETRY,
            timeout=30,
        )
        future.result(timeout=30)


def collect_one(state: dict[str, Any], observer: Observer) -> None:
    check_publication_limit(state, "new")
    event = new_investigation_payload()
    if not state.get("first_publication_at"):
        state["first_publication_at"] = utc_now()
    row: dict[str, Any] = {
        "number": len(state["runs"]) + 1,
        "collector_sha256": state["collector_sha256"],
        "event": event,
        "published_at": utc_now(),
        "publish_status": "submitted_unconfirmed",
        "observations": [],
        "audit_events": [],
        "validation": "not_completed",
    }
    state["runs"].append(row)
    state["phase"] = "publishing"
    persist(state)
    started = time.monotonic()
    observer.publish(event)
    row["publish_status"] = "acknowledged"
    row["publish_ack_seconds"] = round(time.monotonic() - started, 6)
    state["phase"] = "waiting_for_durable_completion"
    persist(state)
    since = (timestamp(row["published_at"]) - timedelta(seconds=5)).isoformat()
    while True:
        check_window(state)
        durable = observer.durable(str(event["event_id"]))
        if not row["observations"] or durable != row["observations"][-1]["durable"]:
            row["observations"].append({"observed_at": utc_now(), "durable": durable})
            row["durable"] = durable
            persist(state)
        if durable["attempts"] > 1 or durable["status"] == "failed":
            row["audit_events"] = observer.audit(str(event["event_id"]), since)
            raise MeasurementStop(
                "unexpected_durable_retry" if durable["attempts"] > 1 else "durable_failure"
            )
        if durable["status"] == "completed":
            if durable["attempts"] != 1:
                raise MeasurementStop("completed_without_one_attempt")
            row["confirmation_seconds"] = round(time.monotonic() - started, 6)
            break
        if time.monotonic() - started >= RUN_SECONDS:
            row["audit_events"] = observer.audit(str(event["event_id"]), since)
            raise MeasurementStop("durable_completion_deadline")
        time.sleep(POLL_SECONDS)
    row["reviews"] = observer.reviews(str(event["event_id"]))
    state["phase"] = "waiting_for_audit_correlation"
    deadline = time.monotonic() + AUDIT_SECONDS
    while True:
        check_window(state)
        row["audit_events"] = observer.audit(str(event["event_id"]), since)
        row["audit_gaps"] = audit_gaps(row["audit_events"])
        persist(state)
        if not row["audit_gaps"]:
            break
        if time.monotonic() >= deadline:
            raise MeasurementStop("required_audit_evidence_missing")
        time.sleep(POLL_SECONDS)
    row["audit_durations_seconds"] = durations(row["audit_events"])
    row["validation"] = "passed"
    row["validated_at"] = utc_now()
    persist(state)
    print(
        json.dumps(
            {
                "run": row["number"],
                "validation": "passed",
                "confirmation_seconds": row["confirmation_seconds"],
                "audit_events": len(row["audit_events"]),
                "review_records": len(row["reviews"]),
                "delivered_findings": sum(record["finding_count"] for record in row["reviews"]),
            }
        ),
        flush=True,
    )


def recover_stopped_checkpoint(state: dict[str, Any], observer: Observer) -> None:
    check_window(state)
    archive_path = HERE / "initial-stop-collector-v1.zip"
    with zipfile.ZipFile(archive_path) as archive:
        original_source_hash = hashlib.sha256(archive.read("collect.py")).hexdigest()
        original_checkpoint = archive.read("metrics.json")
    if original_source_hash != state["collector_sha256"]:
        raise MeasurementStop("original_collector_archive_hash_mismatch")
    if original_checkpoint != STATE_FILE.read_bytes():
        raise MeasurementStop("original_stopped_checkpoint_changed")
    row = state["runs"][-1]
    event_id = str(row["event"]["event_id"])
    if observer.durable(event_id) != row["durable"]:
        raise MeasurementStop("durable_state_changed_before_readonly_recovery")
    if observer.reviews(event_id) != row["reviews"]:
        raise MeasurementStop("review_effects_changed_before_readonly_recovery")
    since = (timestamp(row["published_at"]) - timedelta(seconds=5)).isoformat()
    deadline = time.monotonic() + AUDIT_SECONDS
    while True:
        check_window(state)
        recovered = observer.audit(event_id, since)
        if not audit_gaps(recovered):
            break
        if time.monotonic() >= deadline:
            raise MeasurementStop("recovered_paired_audit_boundaries_still_missing")
        time.sleep(POLL_SECONDS)
    original_ids = {(event["insert_id"], event["timestamp"]) for event in row["audit_events"]}
    recovered_ids = {(event["insert_id"], event["timestamp"]) for event in recovered}
    if not original_ids <= recovered_ids:
        raise MeasurementStop("original_audit_events_not_preserved_by_recovery")
    current_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    for existing in state["runs"]:
        existing["collector_sha256"] = original_source_hash
    row["initial_audit_events"] = row["audit_events"]
    row["audit_events"] = recovered
    row["audit_gaps"] = []
    row["audit_durations_seconds"] = durations(recovered)
    row["validation"] = "passed"
    row["validated_at"] = utc_now()
    row["evidence_recovery"] = {
        "reason": "paired_start_milestone_not_visible_in_initial_query",
        "observed_at": utc_now(),
        "verifier_sha256": current_hash,
        "initial_audit_event_count": len(row["initial_audit_events"]),
        "recovered_audit_event_count": len(recovered),
        "new_publications_for_recovery": 0,
    }
    original_state = json.loads(original_checkpoint)
    state["previous_stops"] = [
        {
            "reason": state["stop_reason"],
            "new_event_count": len(state["runs"]),
            "last_checkpoint_at": original_state["last_checkpoint_at"],
            "checkpoint_sha256": hashlib.sha256(original_checkpoint).hexdigest(),
        }
    ]
    state["collector_history"] = [
        {
            "sha256": original_source_hash,
            "source_archive": archive_path.name,
            "source_archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
            "new_events_executed": list(range(1, 8)),
        },
        {"sha256": current_hash, "source_file": "collect.py"},
    ]
    state["collector_sha256"] = current_hash
    state["collector_repair"] = {
        "approved_by_user": True,
        "recorded_at": utc_now(),
        "change": "Wait for both start and completion milestones before computing stage durations.",
        "deployed_code_or_configuration_changed": False,
        "original_count_time_and_spending_limits_preserved": True,
        "paused_seconds_before_recovery": (
            datetime.now(UTC) - timestamp(original_state["last_checkpoint_at"])
        ).total_seconds(),
    }
    state.pop("stop_reason")
    state["phase"] = "resumed_after_readonly_evidence_recovery"
    persist(state)


def collect_replays(state: dict[str, Any], observer: Observer) -> None:
    state["phase"] = "publishing_completed_event_replays"
    selected = state["runs"][::4][:MAX_REPLAYS]
    for original in selected:
        check_publication_limit(state, "replay")
        replay = {
            "original_run": original["number"],
            "published_at": utc_now(),
            "publish_status": "submitted_unconfirmed",
            "per_message_delivery_acknowledgement": "not_available",
        }
        state["replays"].append(replay)
        persist(state)
        observer.publish(original["event"])
        replay["publish_status"] = "acknowledged"
        persist(state)
    state["phase"] = "observing_replay_effects"
    deadline = time.monotonic() + REPLAY_SECONDS
    while time.monotonic() < deadline:
        check_window(state)
        for original in selected:
            current = observer.durable(str(original["event"]["event_id"]))
            if current != original["durable"]:
                raise MeasurementStop("durable_state_changed_after_replay")
        time.sleep(POLL_SECONDS)
    for original, replay in zip(selected, state["replays"], strict=True):
        event_id = str(original["event"]["event_id"])
        reviews = observer.reviews(event_id)
        if reviews != original["reviews"]:
            raise MeasurementStop("review_effects_changed_after_replay")
        since = (timestamp(original["published_at"]) - timedelta(seconds=5)).isoformat()
        events = observer.audit(event_id, since)
        before = {event["invocation_id"] for event in original["audit_events"]}
        after = {event["invocation_id"] for event in events}
        if before != after:
            raise MeasurementStop("new_agent_invocation_after_completed_replay")
        replay["observation"] = "unchanged_effects_during_bounded_window"
        replay["observation_window_seconds"] = REPLAY_SECONDS
        replay["review_records"] = len(reviews)
        replay["observed_at"] = utc_now()
    persist(state)


def summarize(state: dict[str, Any]) -> dict[str, Any]:
    passed = [row for row in state["runs"] if row["validation"] == "passed"]
    latencies = [row["confirmation_seconds"] for row in passed]
    return {
        "unique_event_publication_attempts": len(state["runs"]),
        "unique_event_publications_acknowledged": sum(
            row["publish_status"] == "acknowledged" for row in state["runs"]
        ),
        "completed_with_required_evidence": len(passed),
        "durable_completed": sum(
            row.get("durable", {}).get("status") == "completed" for row in state["runs"]
        ),
        "unvalidated_attempts": len(state["runs"]) - len(passed),
        "replay_publication_attempts": len(state["replays"]),
        "replay_publications_acknowledged": sum(
            row["publish_status"] == "acknowledged" for row in state["replays"]
        ),
        "confirmation_seconds": {
            "n": len(latencies),
            "minimum": min(latencies) if latencies else None,
            "median": statistics.median(latencies) if latencies else None,
            "maximum": max(latencies) if latencies else None,
        },
        "actual_cost_sek": None,
        "actual_cost_status": "not_measured_from_payload_free_audit",
    }


def export_csv(state: dict[str, Any]) -> None:
    with (HERE / "runs.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = [
            "run",
            "event_id",
            "publish_status",
            "durable_status",
            "attempts",
            "validation",
            "confirmation_seconds",
            "audit_events",
            "review_records",
            "delivered_findings",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in state["runs"]:
            reviews = row.get("reviews")
            writer.writerow(
                {
                    "run": row["number"],
                    "event_id": row["event"]["event_id"],
                    "publish_status": row["publish_status"],
                    "durable_status": row.get("durable", {}).get("status", "not_observed"),
                    "attempts": row.get("durable", {}).get("attempts"),
                    "validation": row["validation"],
                    "confirmation_seconds": row.get("confirmation_seconds"),
                    "audit_events": len(row["audit_events"]),
                    "review_records": len(reviews) if reviews is not None else None,
                    "delivered_findings": (
                        sum(record["finding_count"] for record in reviews)
                        if reviews is not None
                        else None
                    ),
                }
            )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--pilot", action="store_true")
    mode.add_argument("--continue-approved-batch", action="store_true")
    mode.add_argument("--resume-recovered-batch", action="store_true")
    parser.add_argument("--execute", action="store_true", required=True)
    args = parser.parse_args()
    if args.pilot:
        if STATE_FILE.exists():
            raise MeasurementStop("existing_measurement_will_not_be_overwritten")
        state: dict[str, Any] = {
            "schema_version": 1,
            "created_at": utc_now(),
            "project": PROJECT,
            "authorization": {
                "max_new_investigations": MAX_NEW,
                "max_completed_event_replays": MAX_REPLAYS,
                "ceiling_sek": 500,
                "window_seconds": WINDOW_SECONDS,
                "pilot_first": True,
                "no_iam_configuration_deployment_or_exception_changes": True,
                "no_fault_injection": True,
            },
            "method": {
                "poll_seconds": POLL_SECONDS,
                "run_completion_deadline_seconds": RUN_SECONDS,
                "audit_ingestion_grace_seconds": AUDIT_SECONDS,
                "confirmation_latency": "client_publish_start_to_first_completed_poll_monotonic",
                "stage_latency": "paired_runtime_invocation_audit_timestamps",
                "replay_boundary": (
                    "Pub/Sub publication acknowledged; unchanged durable/review/agent effects "
                    "observed for a bounded window, not per-message Eventarc delivery proof."
                ),
                "cost_boundary": (
                    "500 SEK authorization ceiling, not an independently enforced platform "
                    "billing cap. Event/time limits are enforced; in-flight work may continue."
                ),
                "finding_boundary": (
                    "Only delivered department/counts and successful deterministic gate "
                    "milestones are observed; no raw IAM, canonical findings or model text "
                    "exported."
                ),
            },
            "collector_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "first_publication_at": None,
            "phase": "prepared",
            "runs": [],
            "replays": [],
        }
    else:
        state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        if args.resume_recovered_batch:
            if (
                state.get("phase") != "stopped"
                or state.get("stop_reason") != "missing_audit_duration_boundary"
                or len(state["runs"]) != 7
                or state["replays"]
            ):
                raise MeasurementStop("only_the_approved_stopped_checkpoint_can_resume")
        else:
            if state.get("phase") != "pilot_passed" or len(state["runs"]) != 1:
                raise MeasurementStop("only_a_passed_single_pilot_can_continue")
            if state["runs"][0].get("validation") != "passed":
                raise MeasurementStop("pilot_did_not_pass")
            if state["collector_sha256"] != hashlib.sha256(Path(__file__).read_bytes()).hexdigest():
                raise MeasurementStop("collector_changed_after_pilot")
    observer = None
    code = 0
    try:
        observer = Observer()
        if args.resume_recovered_batch:
            recover_stopped_checkpoint(state, observer)
        target = 1 if args.pilot else MAX_NEW
        while len(state["runs"]) < target:
            collect_one(state, observer)
        if args.pilot:
            state["phase"] = "pilot_passed"
        else:
            collect_replays(state, observer)
            state["phase"] = "completed"
    except MeasurementStop as error:
        state["phase"] = "stopped"
        state["stop_reason"] = str(error)
        code = 2
    except (
        GoogleAPIError,
        GoogleAuthError,
        RequestException,
        TimeoutError,
        ValueError,
        OSError,
    ) as error:
        state["phase"] = "collector_error"
        state["error_class"] = type(error).__name__
        code = 3
    finally:
        state["summary"] = summarize(state)
        persist(state)
        export_csv(state)
        if observer is not None:
            observer.close()
    print(
        json.dumps(
            {
                "phase": state["phase"],
                "stop_reason": state.get("stop_reason"),
                "error_class": state.get("error_class"),
                "summary": state["summary"],
            },
            indent=2,
        ),
        flush=True,
    )
    return code


def safe_exception_hook(
    exc_type: type[BaseException], _value: BaseException, _traceback: Any
) -> None:
    print(
        json.dumps({"collector_error_class": exc_type.__name__, "details_withheld": True}),
        file=sys.stderr,
        flush=True,
    )


if __name__ == "__main__":
    sys.excepthook = safe_exception_hook
    try:
        lock = LOCK_FILE.open("x", encoding="ascii")
    except FileExistsError:
        raise SystemExit("another_collector_or_unresolved_lock_exists") from None
    try:
        lock.write(str(os.getpid()))
        lock.flush()
        exit_code = main()
    finally:
        lock.close()
        LOCK_FILE.unlink()
    raise SystemExit(exit_code)
