"""Offline guard checks; these tests never instantiate a cloud client."""

import copy
import io
import unittest
from contextlib import redirect_stdout
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import Mock, patch

import collect


def events() -> list[dict[str, str]]:
    rows = []
    for index, actor in enumerate(("orchestrator", "access_auditor", "escalation_agent")):
        for outcome in ("started", "completed"):
            rows.append(
                {
                    "actor": actor,
                    "event": "investigation.run",
                    "outcome": outcome,
                    "invocation_id": f"invocation-{index}",
                }
            )
    for actor in collect.STEPS:
        for outcome in ("started", "completed"):
            rows.append(
                {
                    "actor": actor,
                    "event": "agent.run",
                    "outcome": outcome,
                    "invocation_id": "invocation-0",
                }
            )
    rows.append(
        {
            "actor": "audit_iam_policy",
            "event": "tool.call",
            "outcome": "completed",
            "invocation_id": "invocation-1",
        }
    )
    for outcome in ("submitted", "completed"):
        rows.append(
            {
                "actor": "access_auditor",
                "event": "model.request",
                "outcome": outcome,
                "invocation_id": "invocation-1",
            }
        )
    for row in rows:
        row["timestamp"] = (
            "2026-10-27T21:00:00Z"
            if row["outcome"] in {"started", "submitted"}
            else "2026-10-27T21:00:01Z"
        )
    return rows


class CollectorGuards(unittest.TestCase):
    def test_complete_metadata_passes(self) -> None:
        self.assertEqual(collect.audit_gaps(events()), [])

    def test_missing_completion_gate_is_not_success(self) -> None:
        rows = [row for row in events() if row["actor"] != "escalation_gate"]
        self.assertIn("escalation_gate_runtime_completion", collect.audit_gaps(rows))

    def test_completion_without_its_start_is_not_ready(self) -> None:
        rows = [
            row
            for row in events()
            if not (row["actor"] == "escalation_gate" and row["outcome"] == "started")
        ]
        self.assertIn("escalation_gate_runtime_start", collect.audit_gaps(rows))

    def test_late_start_is_awaited_without_republishing(self) -> None:
        complete = events()
        partial = [
            row
            for row in complete
            if not (row["actor"] == "escalation_gate" and row["outcome"] == "started")
        ]
        observer = SimpleNamespace(
            publish=Mock(),
            durable=Mock(
                return_value={"status": "completed", "attempts": 1, "updated_at": collect.utc_now()}
            ),
            reviews=Mock(return_value=[]),
            audit=Mock(side_effect=[partial, complete]),
        )
        state = {
            "runs": [],
            "replays": [],
            "first_publication_at": None,
            "collector_sha256": "offline-test",
        }
        with (
            patch.object(collect, "persist"),
            patch.object(collect.time, "sleep"),
            redirect_stdout(io.StringIO()),
        ):
            collect.collect_one(state, observer)
        self.assertEqual(observer.publish.call_count, 1)
        self.assertEqual(observer.audit.call_count, 2)
        self.assertEqual(state["runs"][0]["validation"], "passed")

    def test_refusal_stops_the_batch(self) -> None:
        rows = events() + [
            {"actor": "model-armor", "event": "model_armor.input", "outcome": "refused"}
        ]
        with self.assertRaisesRegex(collect.MeasurementStop, "audit_failure_or_refusal"):
            collect.audit_gaps(rows)

    def test_new_and_replay_limits(self) -> None:
        below = {"runs": [{}] * 19, "replays": [{}] * 4, "first_publication_at": None}
        for kind in ("new", "replay"):
            collect.check_publication_limit(below, kind)
        state = {"runs": [{}] * 20, "replays": [{}] * 5, "first_publication_at": None}
        for kind in ("new", "replay"):
            with self.assertRaisesRegex(collect.MeasurementStop, "publication_count_limit"):
                collect.check_publication_limit(state, kind)

    def test_expired_window_stops_before_publication(self) -> None:
        state = {
            "runs": [],
            "replays": [],
            "first_publication_at": (datetime.now(UTC) - timedelta(hours=2)).isoformat(),
        }
        with self.assertRaisesRegex(collect.MeasurementStop, "collection_window_expired"):
            collect.check_publication_limit(state, "new")

    def test_audit_projection_discards_unselected_values(self) -> None:
        event_id = "00000000-0000-0000-0000-000000000001"
        entry = {
            "timestamp": "2026-10-27T21:00:00Z",
            "insertId": "test-insert",
            "jsonPayload": {
                "investigation_id": event_id,
                "invocation_id": "invocation-1",
                "actor": "access_auditor",
                "event": "agent.run",
                "outcome": "completed",
                "extra": "discard-me",
            },
        }
        safe = collect.safe_audit(entry, event_id)
        self.assertNotIn("discard-me", str(safe))
        invalid = copy.deepcopy(entry)
        invalid["jsonPayload"]["actor"] = "not-a-repository-owned-actor"
        with self.assertRaisesRegex(collect.MeasurementStop, "unexpected_audit_metadata"):
            collect.safe_audit(invalid, event_id)

    def test_empty_results_do_not_become_zero_latency(self) -> None:
        summary = collect.summarize({"runs": [], "replays": []})
        self.assertIsNone(summary["confirmation_seconds"]["median"])
        self.assertIsNone(summary["actual_cost_sek"])


if __name__ == "__main__":
    unittest.main()
